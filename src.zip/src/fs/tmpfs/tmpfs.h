#pragma once

#include "../vfs/vfs.h"

void tmpfs_init();
